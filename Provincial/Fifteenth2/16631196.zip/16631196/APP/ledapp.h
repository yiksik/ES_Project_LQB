#ifndef __LEDAPP_H
#define __LEDAPP_H

#include "system.h"
void led_renew(void);

#endif
