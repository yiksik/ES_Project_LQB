#ifndef __KEYAPP_H
#define __KEYAPP_H

#include "system.h"
void key_proc(void);


#endif
