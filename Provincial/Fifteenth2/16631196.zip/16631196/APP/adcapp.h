#ifndef __ADCAPP_H
#define __ADCAPP_H

#include "system.h"

void adc_init(void);
void adc_proc(void);

#endif
