#ifndef __SCHEDULER_H
#define __SCHEDULER_H

#include "system.h"

void scheduler_run(void);

#endif
